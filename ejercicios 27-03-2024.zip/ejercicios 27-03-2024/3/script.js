let contador=0;

document.getElementById('btnClic').addEventListener('click',function(){
    contador++;
    document.getElementById('contador').textContent = `Has hecho ${contador} clics`;
    });