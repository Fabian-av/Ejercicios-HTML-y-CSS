document.getElementById('btnAgregar').addEventListener('click', function()
{
    let nuevoElemento= document.getElementById('nuevoElemento').value;

    if(nuevoElemento)
    {
        let li = document.createElement('li');
        li.textContent=nuevoElemento;
        let btnEliminar= document.createElement('button');
        btnEliminar.textContent='Eliminar';
        btnEliminar.addEventListener('click', function(){
        li.remove();
        });
        li.appendChild(btnEliminar);
        document.getElementById('lista').appendChild(li);
        document.getElementById('nuevoElemento').value='';
    }
    else{
        alert('Por favor, ingrese un texto valido.');
    }
});
