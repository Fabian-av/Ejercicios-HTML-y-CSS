document.getElementById('formularioRegistro').addEventListener('submit',function(event){
    event.preventDefault();

    let nombre= document.getElementById('nombre').value;
    let email= document.getElementById('email').value;
    let errorMensaje=document.getElementById('errorMensaje');

    if (nombre ===''|| email==='')
    {    
        errorMensaje.textContent='Por favor, complete todos los campos.';
    }
    else{
        errorMensaje.textContent='';
        alert('Formulario enviado correctamente');
    }
});