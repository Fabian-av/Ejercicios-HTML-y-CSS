let tiempoRestante = 10;
let temporizador;

document.getElementById('btnIniciar').addEventListener('click', function(){

    if(temporizador) clearInterval(temporizador);
    tiempoRestante = 10;
    document.getElementById('tiempo').textContent= tiempoRestante;
    temporizador = setInterval( function() 
    {
        if (tiempoRestante > 0 ) {
            tiempoRestante --;
            document.getElementById('tiempo').textContent=tiempoRestante;
            document.getElementById('contenedor').style.backgroundColor='rgb(30, 135, 210)';
            }
            else{
                document.getElementById('contenedor').style.backgroundColor='red';
                clearInterval(temporizador);
                alert('¡Tiempo agotado!');
                
            }
    }, 
    1000);
});