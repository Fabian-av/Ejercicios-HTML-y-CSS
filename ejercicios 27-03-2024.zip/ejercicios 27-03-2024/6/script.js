
document.getElementById('btnSuma').addEventListener('click',function(){
    let num1 =parseFloat(document.getElementById('numero1').value);
    let num2= parseFloat(document.getElementById('numero2').value);
    document.getElementById('resultado').textContent = num1 + num2;
});

document.getElementById('btnResta').addEventListener('click',function(){
    let num1 =parseFloat(document.getElementById('numero1').value);
    let num2= parseFloat(document.getElementById('numero2').value);
    document.getElementById('resultado').textContent=num1-num2;
});

document.getElementById('btnMultiplicacion').addEventListener('click',function(){
    let num1 =parseFloat(document.getElementById('numero1').value);
    let num2= parseFloat(document.getElementById('numero2').value);
    document.getElementById('resultado').textContent=num1*num2;
});

document.getElementById('btnDivision').addEventListener('click', function(){
    let num1 =parseFloat(document.getElementById('numero1').value);
    let num2= parseFloat(document.getElementById('numero2').value);
    document.getElementById('resultado').textContent=num1/num2;

    if(num2!==0){
        document.getElementById('resultado').textContent=num1/num2;
    }
    else{
        alert ('No se puede dividir entre cero')
    }
});