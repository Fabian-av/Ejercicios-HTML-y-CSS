document.getElementById('btnCambioFondo').addEventListener('click', function()
{
        document.body.style.backgroundColor = 'lightblue';
    });
