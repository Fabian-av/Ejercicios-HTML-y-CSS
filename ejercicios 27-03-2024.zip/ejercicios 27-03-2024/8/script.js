/*
const btnAgregar = document.getElementById('btnAgregar');
const tareaInput = document.getElementById('tareaInput');
const listaTareas = document.getElementById('listaTareas');

btnAgregar.addEventListener('click', function() {
const tareaTexto = tareaInput.value.trim();

    if(tareaTexto !=='') {
        const li = document.createElement ('li');
        li.textContent = tareaTexto;

        const btnEliminar = document.createElement('button');
        btnEliminar.textContent = 'Eliminar';
        btnEliminar.addEventListener('click', () => li.remove());

        const btnCompletar = document.createElement('button');
        btnCompletar.textContent = 'Completar';
        btnCompletar.addEventListener('click', () => {
            li.classList.toggle('Completada');
        });

        li.appendChild(btnCompletar);
        li.appendChild(btnEliminar);
        listaTareas.appendChild(li);

        tareaInput.value=''; //se limpia el campo de entrada
        } else {
            alert('Por favor, ingresar una tarea')
        }
});*/


const btnAgregar = document.getElementById('btnAgregar');
const tareaInput = document.getElementById('tareaInput');
const listaTareas = document.getElementById('listaTareas');

btnAgregar.addEventListener('click', function() {
    const tareaTexto = tareaInput.value.trim();

    if (tareaTexto !== '') {
        const li = document.createElement('li');
        li.textContent = tareaTexto;

        const btnEliminar = document.createElement('button');
        btnEliminar.textContent = 'Eliminar';
        btnEliminar.addEventListener('click', () => li.remove());

        const btnCompletar = document.createElement('button');
        btnCompletar.textContent = 'Completar';
        btnCompletar.addEventListener('click', () => {
            li.classList.toggle('completada');
        });

        li.appendChild(btnCompletar);
        li.appendChild(btnEliminar);
        listaTareas.appendChild(li);

        tareaInput.value = '';  // Limpiar el campo de entrada
    } else {
        alert('Por favor, ingresa una tarea.');
    }
});