document.getElementById('btnCambiarTexto').addEventListener('click',function(){

    document.getElementById('parrafo').textContent='¡El texto ha sido cambiado!' 
});