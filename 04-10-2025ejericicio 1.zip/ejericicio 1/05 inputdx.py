resultado= input ("Intrese su nombre")
print(type(resultado))
print(resultado)

edad=input("Ingrese su edad en numero")
print(type(edad))
print(edad + 3)