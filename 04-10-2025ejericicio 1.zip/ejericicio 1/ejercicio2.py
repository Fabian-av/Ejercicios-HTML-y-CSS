num=[5,9,2,7,2,6,8]

for num in range(2,9):
    if num % 2 == 0:
        print(num)