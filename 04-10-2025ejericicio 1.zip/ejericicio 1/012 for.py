elemento=["dedos","uñas","manos","brazos","Pecho","cabeza"]
for i in elemento:
    print(i)