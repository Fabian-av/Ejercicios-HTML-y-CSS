class Gato:
    def __init__(self, nombre, color, raza, edad, peso):
                self.nombre= nombre
                self.color= color
                self.raza= raza
                self.edad=edad
                self.peso=peso
                print(f"se a creado la clase gato {self.nombre} de color {self.color} es raza {self.raza}, tiene {self.edad} años y pesa {self.peso} kilos ") 
                input("Presione la tecla enter para continuar")

    def describir(self):
                print(f"{self.nombre}es un gato de color{self.color}")
                input(f"{self.nombre}Presione la tecla enter para continuar")

    def sonido(self):
                print(f"{self.nombre} hace un sonido para comunicarse")
                input(f"{self.nombre}Presione la tecla enter para continuar")

mi_gato=Gato("Rubi","amarillo","criolla","10","7")

mi_gato.describir()
mi_gato.sonido()
