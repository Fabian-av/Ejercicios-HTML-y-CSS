temperatura =int (input("Ingresa una temperatura (en numero): "))
tipoTemperatura= str(input("ingresa la letra 'F' si es fahrenheit, y la letra 'C' para celsius: "))



if tipoTemperatura == "f" or  tipoTemperatura =="F":
    #resultadoResta= (temperatura - 32)  * 5/9
   # resultadoTotalF= (resultadoResta *  5/9)
    print((temperatura - 32)  * 5/9)
    
elif tipoTemperatura == "c" or tipoTemperatura == "C":
    #resultadoMult=(temperatura * 9/5) +32
    #resultadoTotalC= (resultadoMult + 32 )
    print((temperatura * 9/5) +32)

else:
    print ("Valor invalido")
    


