elemento=["dedos","uñas","manos","brazos","Pecho","cabeza"]
elemento.insert(4,"cabello")
print(elemento)
elemento.remove("Pecho")
print(elemento)
print("manos" in elemento)
print(len(elemento))