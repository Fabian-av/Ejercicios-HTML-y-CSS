codigo = 38
print(codigo<70 and codigo>20)
print("se cumple la condicion")
print(codigo<70 or codigo>20)
print("Se cumple a menos una condicion")
print(True)
print(not True)
