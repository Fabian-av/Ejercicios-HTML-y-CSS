elemento=["dedos","uñas","manos","brazos","Pecho","cabeza"]
i=1
while i <= 5:
    print(i)
    i= i+1

i=1
while i <= 5:
    print (i* "Bucle while ")
    i= i +1

i=0
while i< len(elemento):
    print(elemento[i])
    i=i+1