puntaje= 95

if puntaje > 100 or puntaje < 0:
    print ("Numero invalido")

else:
    if puntaje >= 95 and puntaje <= 100:
        print ("Aprobo el examen con honores")
    elif puntaje >=60 and puntaje <=94  :
        print("Aprobado")
    else:
        print("Reprobo")


print("=================")