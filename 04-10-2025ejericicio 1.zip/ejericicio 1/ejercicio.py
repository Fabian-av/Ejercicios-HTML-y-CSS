texto= "Hola"
print("texto")
print(texto.find("o")) #busca un caracter en especifico 
print(texto.upper())
print(texto.lower())
print(texto.replace("ola", "Jueves"))
nuevoElemento= ""
print(texto,nuevoElemento)