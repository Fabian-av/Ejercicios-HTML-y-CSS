elemento=["dedos","uñas","manos","brazos","Pecho","cabeza"]
print(elemento[3])
print(elemento)
elemento[2]="codos"
print(elemento)

print(elemento[:3])#muentra los 3 ultimos 


